package jarhead.trajectorysequence;


public class EmptySequenceException extends RuntimeException { }
